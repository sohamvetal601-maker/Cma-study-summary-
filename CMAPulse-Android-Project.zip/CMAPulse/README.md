# CMA Pulse

A focused Android study timer for CMA students.

## Features
- Custom study slots: name, start time, duration
- Start-now timer with session tracking
- Daily / weekly / monthly aggregates
- Persistent local history
- Focus blocker using Android Accessibility Service (user must explicitly enable it)
- Default distraction list includes Instagram, YouTube, Facebook, X/Twitter, TikTok and Valorant package

## Important Android limitation
A normal third-party app cannot silently enable Android's system Focus mode or disable arbitrary apps. CMA Pulse therefore uses an Accessibility Service: when a study session is active, it detects blocked apps and opens a blocking screen. The user must enable the service in Android Settings. This follows Android's permission model and keeps control with the user.

## Build
Open in Android Studio and build the debug APK. The project uses AGP 9.4.0 and compile/target SDK 36.
