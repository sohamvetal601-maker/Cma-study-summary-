package com.cmapulse.app;
import android.content.*;import java.util.*;
public class SlotAlarmReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){int id=i.getIntExtra("id",0);for(Store.Slot s:Store.slots(c))if(s.id==id){Store.start(c,s);break;}}}
