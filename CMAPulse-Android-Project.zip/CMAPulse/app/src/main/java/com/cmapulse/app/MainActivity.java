package com.cmapulse.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.provider.Settings;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list; TextView total; Handler h=new Handler(Looper.getMainLooper());
    int bg=Color.rgb(15,23,42), card=Color.rgb(30,41,59), accent=Color.rgb(34,197,94), text=Color.WHITE, muted=Color.rgb(148,163,184);
    @Override public void onCreate(Bundle b){super.onCreate(b); render();}
    TextView tv(String s,float sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(text);t.setPadding(18,12,18,12);return t;}
    GradientDrawable gd(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(text);b.setTextSize(14);b.setAllCaps(false);b.setBackground(gd(accent,28));return b;}
    void render(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,20,18,18);root.setBackgroundColor(bg);
        TextView head=tv("CMA PULSE",26);head.setTypeface(null,1);root.addView(head);
        TextView sub=tv("Your study time. Measured, not guessed.",14);sub.setTextColor(muted);root.addView(sub);
        total=tv("Today  •  "+fmt(Store.todayMs(this)),22);total.setTypeface(null,1);root.addView(total);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button add=btn("+  New slot"); row.addView(add,new LinearLayout.LayoutParams(0,58,1));
        Button focus=btn("Focus setup"); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,58,1);fp.setMargins(10,0,0,0);row.addView(focus,fp); root.addView(row);
        add.setOnClickListener(v->newSlot()); focus.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        TextView stats=tv("THIS WEEK  "+fmt(Store.weekMs(this))+"    •    THIS MONTH  "+fmt(Store.monthMs(this)),15);stats.setTextColor(muted);stats.setPadding(18,18,18,18);root.addView(stats);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);refresh();
    }
    void refresh(){list.removeAllViews(); ArrayList<Store.Slot> slots=Store.slots(this); if(slots.isEmpty()){TextView e=tv("No slots yet. Make your first CMA study slot.\n\nExample: 9:30 PM — Costing",16);e.setTextColor(muted);list.addView(e);return;} for(Store.Slot s:slots){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(8,8,8,8);c.setBackground(gd(card,24));TextView n=tv(s.name+"\n"+s.start+"  •  "+s.minutes+" min",17);n.setTypeface(null,1);c.addView(n);TextView x=tv("Logged: "+fmt(Store.slotTotal(this,s.id)),13);x.setTextColor(muted);c.addView(x);Button go=btn("Start now");c.addView(go,new LinearLayout.LayoutParams(-1,52));go.setOnClickListener(v->startSlot(s));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,12);list.addView(c,cp);} }
    void newSlot(){ final EditText name=new EditText(this);name.setHint("Slot name (e.g. Direct Tax)"); final EditText mins=new EditText(this);mins.setHint("Duration in minutes");mins.setInputType(2); TimePicker tp=new TimePicker(this);tp.setIs24HourView(false); LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(30,0,30,0);box.addView(name);box.addView(mins);TextView lab=tv("Start time",14);lab.setTextColor(muted);box.addView(lab);box.addView(tp); new AlertDialog.Builder(this).setTitle("Create CMA study slot").setView(box).setPositiveButton("Save",(d,w)->{String n=name.getText().toString().trim();int m=60;try{m=Integer.parseInt(mins.getText().toString());}catch(Exception e){} if(n.length()==0)n="CMA Study";String tm=String.format(Locale.getDefault(),"%02d:%02d",tp.getHour(),tp.getMinute());Store.addSlot(this,n,m,tm);refresh();}).setNegativeButton("Cancel",null).show(); }
    void startSlot(Store.Slot s){Store.start(this,s);Intent i=new Intent(this,TimerActivity.class);i.putExtra("id",s.id);startActivity(i);}
    String fmt(long ms){long min=Math.max(0,ms/60000);return (min/60)+"h "+(min%60)+"m";}
    @Override protected void onResume(){super.onResume();if(total!=null){total.setText("Today  •  "+fmt(Store.todayMs(this)));refresh();}}
}
