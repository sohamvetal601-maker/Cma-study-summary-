package com.cmapulse.app;
import android.content.*;import java.text.*;import java.util.*;import org.json.*;
public class Store{
 static String P="data";static android.content.SharedPreferences p(Context c){return c.getSharedPreferences(P,0);} static long now(){return System.currentTimeMillis();}
 static class Slot{int id;String name,start;int minutes;Slot(int i,String n,String s,int m){id=i;name=n;start=s;minutes=m;}}
 static ArrayList<Slot> slots(Context c){ArrayList<Slot>a=new ArrayList<>();try{JSONArray j=new JSONArray(p(c).getString("slots","[]"));for(int i=0;i<j.length();i++){JSONObject o=j.getJSONObject(i);a.add(new Slot(o.getInt("id"),o.getString("name"),o.getString("start"),o.getInt("minutes")));}}catch(Exception e){}return a;}
 static void addSlot(Context c,String n,int m,String time){try{JSONArray j=new JSONArray(p(c).getString("slots","[]"));JSONObject o=new JSONObject();o.put("id",(int)(now()%100000000));o.put("name",n);o.put("start",time);o.put("minutes",Math.max(1,m));j.put(o);p(c).edit().putString("slots",j.toString()).apply();}catch(Exception e){}}
 static void start(Context c,Slot s){p(c).edit().putLong("runStart",now()).putLong("runEnd",now()+s.minutes*60000L).putInt("runId",s.id).putBoolean("focus",true).apply();}
 static long started(Context c){return p(c).getLong("runStart",now());} static long end(Context c){return p(c).getLong("runEnd",now());} static boolean focus(Context c){return p(c).getBoolean("focus",false)&&now()<end(c);}
 static void clearRun(Context c){p(c).edit().putBoolean("focus",false).apply();}
 static boolean blocked(Context c,String pkg){String s=p(c).getString("blocked","com.instagram.android,com.google.android.youtube,com.facebook.katana,com.twitter.android,com.zhiliaoapp.musically,com.riotgames.league.valorant");for(String x:s.split(","))if(x.trim().equals(pkg))return true;return false;}
 static void log(Context c,int id,long ms){String sk="slot_"+id; p(c).edit().putLong(sk,p(c).getLong(sk,0)+ms).apply(); String key="log_"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());p(c).edit().putLong(key,p(c).getLong(key,0)+ms).apply();}
 static long day(Context c,Date d){String key="log_"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);return p(c).getLong(key,0);} static long todayMs(Context c){return day(c,new Date());}
 static long weekMs(Context c){Calendar x=Calendar.getInstance();x.set(Calendar.DAY_OF_WEEK,x.getFirstDayOfWeek());long z=0;for(int i=0;i<7;i++){z+=day(c,x.getTime());x.add(Calendar.DATE,1);}return z;}
 static long monthMs(Context c){Calendar x=Calendar.getInstance();x.set(Calendar.DAY_OF_MONTH,1);int n=x.getActualMaximum(Calendar.DAY_OF_MONTH);long z=0;for(int i=0;i<n;i++){z+=day(c,x.getTime());x.add(Calendar.DATE,1);}return z;}
 static long slotTotal(Context c,int id){return p(c).getLong("slot_"+id,0);}
}
