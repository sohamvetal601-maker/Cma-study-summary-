plugins { id("com.android.application") }

android { namespace = "com.cmapulse.app"; compileSdk = 36
    defaultConfig { applicationId = "com.cmapulse.app"; minSdk = 26; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}
